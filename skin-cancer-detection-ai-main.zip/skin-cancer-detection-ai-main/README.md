# skin-cancer-detection-ai
A professional AI-powered skin lesion analysis system using Deep Learning (Vision Transformers) to assist in early dermatological screening. Built with Streamlit and Hugging Face.
